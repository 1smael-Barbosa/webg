import java.util.Scanner;

public class CalculoSalario {
    public static void main(String[] args) {
        // Solicita o nome e o salário da pessoa
        try (Scanner scanner = new Scanner(System.in)) {
            // Solicita o nome e o salário da pessoa
            System.out.print("Digite o nome: ");
            String nome = scanner.nextLine();
            
            System.out.print("Digite o salário: ");
            double salario = scanner.nextDouble();
            
            // Verifica se o salário é inferior a 1500
            if (salario < 1500) {
                // Aplica um aumento de 20%
                salario *= 1.20;
            } else {
                // Aplica um aumento de 7%
                salario *= 1.07;
            }
            
            // Exibe o nome e o novo salário
            System.out.println("Nome: " + nome);
            System.out.println("Novo salário: " + salario);
        }
    }
}
